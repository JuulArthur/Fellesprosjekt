package com.controller;

import java.util.ArrayList;

public interface IServerResponse {
	public boolean recievedObjectRespone(boolean success, ArrayList<Object> al);
	
}
